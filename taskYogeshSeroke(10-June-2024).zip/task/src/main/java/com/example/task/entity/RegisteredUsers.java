package com.example.task.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "registered_users")
@Data
public class RegisteredUsers {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int registeredUserId;
	
	private String name;
	
	private  String email;
	
	private String mobile;
	
	private String cityName;
}

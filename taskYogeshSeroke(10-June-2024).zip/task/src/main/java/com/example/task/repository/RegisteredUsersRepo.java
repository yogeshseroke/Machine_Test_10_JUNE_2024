package com.example.task.repository;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.task.entity.RegisteredUsers;

@Repository
public interface RegisteredUsersRepo extends JpaRepository<RegisteredUsers, Integer>{

	@Query(value = "SELECT * FROM registered_users WHERE email = :email ORDER BY registered_user_id ASC ", nativeQuery = true)
	ArrayList<RegisteredUsers> findByEmail(@Param("email") String email);

	@Query(value = "SELECT FROM registered_users WHERE name = :name", nativeQuery = true)
	RegisteredUsers findByUserName(@Param("name") String username);

}

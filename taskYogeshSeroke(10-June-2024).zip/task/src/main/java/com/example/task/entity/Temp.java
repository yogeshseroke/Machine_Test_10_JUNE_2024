package com.example.task.entity;

import jakarta.annotation.Generated;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "temp")
@Data
public class Temp {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int tempId;

	private String name;

	private String email;

	private String mobile;

	private String cityName;

}

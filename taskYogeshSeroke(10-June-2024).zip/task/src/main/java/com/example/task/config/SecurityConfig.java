//package com.example.task.config;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.http.HttpMethod;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
//import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.http.SessionCreationPolicy;
//import org.springframework.security.crypto.password.NoOpPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.security.web.access.AccessDeniedHandler;
//import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
//import org.springframework.web.servlet.config.annotation.EnableWebMvc;
//
//
//@Configuration
//@EnableWebSecurity
//@EnableWebMvc
//@ComponentScan
//public class SecurityConfig {
//	@Autowired
//	private CustomUserDetailsService userDetailsService;
//	
//	@Autowired
//	private JwtFilter jwtFilter;
//	
//	@Autowired
//	private JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint;
//	
//	@Bean
//	public DaoAuthenticationProvider provider() {
//		DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
//		provider.setUserDetailsService(userDetailsService);
//		provider.setPasswordEncoder(passwordEncoder());
//		return provider;
//	}
//	
//	@Bean
//	public PasswordEncoder passwordEncoder() {
//		return NoOpPasswordEncoder.getInstance();
//	}
//	
//	public final String[] URLS = { "/test/**" };
//	
//	@Bean
//	public SecurityFilterChain getSecurityFilterChain(HttpSecurity http) throws Exception {
//
//		 http
//         .authorizeHttpRequests(authorizeRequests ->
//             authorizeRequests
//                 .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
//                 .requestMatchers(URLS).permitAll()
//                 .anyRequest().authenticated()
//         )
//         .exceptionHandling(exceptionHandling ->
//             exceptionHandling
//                 .accessDeniedHandler(accessDeniedHandler())
//                 .authenticationEntryPoint(this.jwtAuthenticationEntryPoint)
//         )
//         .sessionManagement(sessionManagement ->
//             sessionManagement.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
//         )
//         .addFilterBefore(this.jwtFilter, UsernamePasswordAuthenticationFilter.class)
//         .authenticationProvider(provider());
//
//     return http.build();
//	}
//	
//	@Bean
//	public AuthenticationManager authenticationManagerBean(AuthenticationConfiguration configuration) throws Exception {
//		return configuration.getAuthenticationManager();
//	}
//	
//	@Bean
//	public AccessDeniedHandler accessDeniedHandler() {
//		return new CustomAccessDeniedHandler();
//	}
//}

package com.example.task.otp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;

import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private TemplateEngine templateEngine;

	public boolean sendMail(String message, String subject, String to, String from) {
		try {

			MimeMessage msg = mailSender.createMimeMessage();

			msg.setSubject(subject);
			MimeMessageHelper helper;
			helper = new MimeMessageHelper(msg, true);
			helper.setFrom(from);
			helper.setTo(to);
			msg.setContent(message, "text/html"); /** Use this or below line **/
			mailSender.send(msg);

			return true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	
	
	

}
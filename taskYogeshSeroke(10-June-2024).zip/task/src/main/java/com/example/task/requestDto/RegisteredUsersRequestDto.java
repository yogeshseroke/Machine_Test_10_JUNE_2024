package com.example.task.requestDto;

import lombok.Data;

@Data
public class RegisteredUsersRequestDto {

	private String name;

	private String email;

	private String mobile;

	private String cityName;
}

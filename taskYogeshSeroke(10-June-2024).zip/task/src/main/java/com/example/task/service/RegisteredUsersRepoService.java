package com.example.task.service;

import com.example.task.requestDto.OtpVerify;
import com.example.task.requestDto.RegisteredUsersRequestDto;
import com.example.task.response.ResponseModel;

public interface RegisteredUsersRepoService {

	public ResponseModel sendRequest(RegisteredUsersRequestDto registeredUsersRequestDto);

	public ResponseModel emailOtpVerify(OtpVerify otp);

}

package com.example.task.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.task.requestDto.OtpVerify;
import com.example.task.requestDto.RegisteredUsersRequestDto;
import com.example.task.response.ResponseModel;
import com.example.task.service.RegisteredUsersRepoService;

@RestController
@RequestMapping("/test")
public class RegisteredUsersController {

	@Autowired
	private RegisteredUsersRepoService registeredUsersRepoService;
	
	@PostMapping("/sendRequest")
	public ResponseEntity<ResponseModel> sendRequest(@RequestBody RegisteredUsersRequestDto registeredUsersRequestDto){
		
		return ResponseEntity.ok(registeredUsersRepoService.sendRequest(registeredUsersRequestDto));
	}
	
	@PostMapping("/emailVerify")
	public ResponseEntity<ResponseModel> emailVerify(@Validated @RequestBody OtpVerify otp) {
		
		return ResponseEntity.ok(registeredUsersRepoService.emailOtpVerify(otp));
	}
}

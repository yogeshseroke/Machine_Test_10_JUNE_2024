package com.example.task.serviceImpl;

import java.util.ArrayList;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.task.entity.EventsRegistration;
import com.example.task.entity.RegisteredUsers;
import com.example.task.entity.Temp;
import com.example.task.otp.EmailService;
import com.example.task.otp.OtpService;
import com.example.task.repository.EventsRegistrationRepo;
import com.example.task.repository.RegisteredUsersRepo;
import com.example.task.repository.TempRepo;
import com.example.task.requestDto.OtpVerify;
import com.example.task.requestDto.RegisteredUsersRequestDto;
import com.example.task.response.ResponseModel;
import com.example.task.service.RegisteredUsersRepoService;



@Service
public class RegisteredUsersRepoServiceImpl implements RegisteredUsersRepoService{

	@Autowired
	private TempRepo tempRepo;
	
	@Autowired
	private EventsRegistrationRepo eventsRegistrationRepo;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private OtpService otpService;
	
	@Autowired
	private RegisteredUsersRepo registeredUsersRepo;
	
	@Override
	public ResponseModel sendRequest(RegisteredUsersRequestDto registeredUsersRequestDto) {
		
		try {

			String email = registeredUsersRequestDto.getEmail();
			
			ArrayList<RegisteredUsers> byEmail = registeredUsersRepo.findByEmail(email);
			
			if(!byEmail.isEmpty()) {
				int emailOtp = otpService.generateOTP("emailOtp");
		        String senderMail = "seroke7744@gmail.com";
		        String template="<!DOCTYPE html>\r\n"
		        		+ "<html>\r\n"
		        		+ "<head>\r\n"
		        		+ "  <title>OTP Verification</title>\r\n"
		        		+ "</head>\r\n"
		        		+ "<body>\r\n"
		        		+ "  <h1>OTP Verification</h1>\r\n"
		        		+ "\r\n"
		        		+ "  <p>Your One-Time Password For Email(OTP) is: <strong> "+emailOtp+" </strong></p>\r\n"
		        		
		        		+ "\r\n"
		        		+ "  <p>Please enter this OTP on the verification page to complete the process.</p>\r\n"
		        		+ "</body>\r\n"
		        		+ "</html>";
		             boolean sendMail = emailService.sendMail(template , "For Email verification"
		        		,email, senderMail);
		             if (sendMail) {
		         		return new ResponseModel<>("Mail sent successfully",  200, "SUCCESS", "Done");
		             } else {
		             
		             	return new ResponseModel<>("Please send correct email", 402, "Denied", "not done");
		             }
			}else {
				
				Temp temp = new Temp();
				temp.setCityName(registeredUsersRequestDto.getCityName());
				temp.setEmail(registeredUsersRequestDto.getEmail());
				temp.setMobile(registeredUsersRequestDto.getMobile());
				temp.setName(registeredUsersRequestDto.getName());
				tempRepo.save(temp);
				
				
				int emailOtp = otpService.generateOTP("emailOtp");
		        String senderMail = "seroke7744@gmail.com";
		        String template="<!DOCTYPE html>\r\n"
		        		+ "<html>\r\n"
		        		+ "<head>\r\n"
		        		+ "  <title>OTP Verification</title>\r\n"
		        		+ "</head>\r\n"
		        		+ "<body>\r\n"
		        		+ "  <h1>OTP Verification</h1>\r\n"
		        		+ "\r\n"
		        		+ "  <p>Your One-Time Password For Email(OTP) is: <strong> "+emailOtp+" </strong></p>\r\n"
		        		
		        		+ "\r\n"
		        		+ "  <p>Please enter this OTP on the verification page to complete the process.</p>\r\n"
		        		+ "</body>\r\n"
		        		+ "</html>";
		             boolean sendMail = emailService.sendMail(template , "For Email verification"
		        		,email, senderMail);
		            
				return new ResponseModel("This is new User that's why userData save on Temp table", 404, "new entry", null);
			}
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseModel("internal server error", 600, "something went wrong", null);
		}
		

		
		
	}

	@Override
	public ResponseModel emailOtpVerify(OtpVerify otp) {
		
		Integer otp2 = otp.getOtp();
		Integer serverOtp = otpService.getOtp("emailOtp");
		
		if (otp2.equals(serverOtp)) {
			otpService.clearOTP("emailOtp");
			
			ArrayList<RegisteredUsers> byEmail = registeredUsersRepo.findByEmail(otp.getEmail());
			if(!byEmail.isEmpty()) {
				int registeredUserId = byEmail.get(0).getRegisteredUserId();
				EventsRegistration eventsRegistration = new EventsRegistration();
				eventsRegistration.setUserId(registeredUserId);
				eventsRegistration.setDate(new Date());
				
				eventsRegistrationRepo.save(eventsRegistration);
			}
			return new ResponseModel<>("Otp matched", 200,"Done", "Verifed");
		} else {
			
			return new ResponseModel<>("Please insert correct otp", 500,"Denied", "not done");
		}
	}

}

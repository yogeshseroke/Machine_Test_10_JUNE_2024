package com.example.task.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "otp")
@Data
public class Otp {

	@Id
	private int otpId;
	
	
}
